package com.example.entity;

import lombok.Data;

@Data
public class ConfigInfo {

    private Integer id;
    private String dataId;
    private String groupId;
    private String content;

}
