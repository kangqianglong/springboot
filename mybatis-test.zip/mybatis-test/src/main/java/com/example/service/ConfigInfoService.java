package com.example.service;

import com.example.entity.ConfigInfo;

import java.util.List;

public interface ConfigInfoService {
    List<ConfigInfo> getList(Object... values);
}
