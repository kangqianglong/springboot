package com.example.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.example.dao.ConfigInfoDao;
import com.example.entity.ConfigInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ConfigInfoImpl implements ConfigInfoService {

    @Autowired
    private ConfigInfoDao configInfoDao;

    @Override
    public List<ConfigInfo> getList(Object... values) {
        LambdaQueryWrapper<ConfigInfo> lambdaQueryWrapper = new LambdaQueryWrapper();
        lambdaQueryWrapper.select().in(ConfigInfo::getId, values);
        return configInfoDao.selectList(lambdaQueryWrapper);
    }
}
