package com.example.controller;

import com.example.entity.ConfigInfo;
import com.example.service.ConfigInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("config-info")
public class ConfigInfoController {

    @Autowired
    private ConfigInfoService configInfoService;

    @GetMapping("get-config")
    public List<ConfigInfo> getConfig() {
        return configInfoService.getList(2, 3, 7);
    }
}

